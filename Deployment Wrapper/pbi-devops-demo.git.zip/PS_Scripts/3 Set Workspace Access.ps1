# AZURE KEY VAULT SECRET AS PARAMETER ================================

Param([Parameter(Mandatory = $true)][String]$AKVSecret, $workspace_name, $Workspace_access_to, $Workspace_Principal_type, $Workspace_Access_type, $ServicePrincipalName)

### ENVIRONMENT VARIABLES ============================================

$workspaceName = $workspace_name
$UserPrincipal = $Workspace_access_to
$UserPrincipalType = $Workspace_Principal_type
$UserPrincipalAccess = $Workspace_Access_type
$ServicePrincipalName = $ServicePrincipalName

Write-Host "Workspace $workspace_name" 
Write-Host "UserPrincipal $UserPrincipal"
Write-Host "UserPrincipalType $UserPrincipalType"
Write-Host "Accesstype $Workspace_Access_type"
Write-Host "ServicePrincipalName $ServicePrincipalName"

### DYNAMIC AUTHENTICATION ===========================================

$AppId = $ENV:APP_ID
$TenantId = $ENV:TENANT_ID
$PublisherEmail = $ENV:PublisherEmail

if ($AppId) {
    Write-Host "Authenticating with Service Principal. App ID: $AppId"
    $PbiSecurePassword = ConvertTo-SecureString $AKVSecret -Force -AsPlainText
    $PbiCredential = New-Object Management.Automation.PSCredential($AppId, $PbiSecurePassword)
    Connect-PowerBIServiceAccount -ServicePrincipal -TenantId $TenantId -Credential $PbiCredential
    Write-Host "Connected via Service Principal"
}
elseif ($PublisherEmail) {
    Write-Host "Authenticating with User Email: $PublisherEmail"
    $password = $AKVSecret | ConvertTo-SecureString -asPlainText -Force
    $username = $PublisherEmail
    $credential = New-Object System.Management.Automation.PSCredential($username, $password)
    Connect-PowerBIServiceAccount -Credential $credential
    Write-Host "Auth via User account"
}
else {
    Write-Error "##vso[task.logissue type=warning] error 41 No values registered on the PublisherEmail or APP_ID variables on the YAML pipeline. Also please check if the AKV Secret and variables are properly configured."
}

### ADD ACCESS PERMISSIONS ===========================================

# Get workspace ID

Write-Host "Getting Workspace ID"
$workspace = Get-PowerBIWorkspace -Name $workspaceName -Scope Organization
$workspaceID = $workspace.Id
$Url1 = "admin/groups/{0}/users" -f $workspaceID
Write-Host "Workspace ID is $workspaceID"
Write-Host "url is $Url1"

# Set admin access for publisher principal.

Write-Host "Setting admin for publisher"

if ($PublisherEmail) {
    try {           
        Write-Host "try user set admin"
        $users = Invoke-PowerBIRestMethod -Url $Url1 -Method Get | ConvertFrom-Json      
        $user = $users.Value | Where-Object identifier -eq $PublisherEmail
        if (!$user) {
            $workspace = Get-PowerBIWorkspace -Name $workspaceName -Scope Organization
            Add-PowerBIWorkspaceUser -Id $workspace.Id -PrincipalType User -Identifier $PublisherEmail -AccessRight Admin  
            return
        }   
        Write-Warning "##vso[task.logissue type=warning] error 68 Group/User already added to workspace: $workspaceName."
    }
    catch {
        $errmsg = Resolve-PowerBIError -Last
        $errmsg.Message
    }
}
else {
    Write-Warning "##vso[task.logissue type=warning] error 76 No values registered on the PublisherEmail or APP_ID variables on the YAML pipeline."
}

# Set desired access to selected principal.
Write-Host "Set desired access"

if (!$UserPrincipal) {
    Write-Warning "##vso[task.logissue type=warning] error 84 No Group/User specified on the Workspace_access_to variable on the YAML pipeline."
}
else {
    try {
        Write-Host "tr SP set admin"
        $users = Invoke-PowerBIRestMethod -Url $Url1 -Method Get | ConvertFrom-Json      
        $user = $users.Value | Where-Object identifier -eq $UserPrincipal
        if (!$user) {
            $workspace = Get-PowerBIWorkspace -Name $workspaceName -Scope Organization
            Add-PowerBIWorkspaceUser -Id $workspace.Id -PrincipalType $UserPrincipalType -Identifier $UserPrincipal -AccessRight $UserPrincipalAccess  
            return
        }   
        Write-Warning "##vso[task.logissue type=warning] error 96 Group/User already added to workspace: $workspaceName."

    }
    catch {
        $errmsg = Resolve-PowerBIError -Last
        $errmsg.Message
    }
}